/***
*	@author Mr.Shroom
*	Created by: Shaun McThomas
*	Last Modified:     06/10/15
*
* First comes first served scheduler.
****/
 
import java.util.*;
import java.io.*;

public class FCFSScheduler implements Scheduler 
{

	private PriorityQueue<Process> arrivalQueue,finishedQueue;
	private int systemTime, totalWaitTime, totalTurnaroundTime;
	
	public FCFSScheduler()
	{
		arrivalQueue = new PriorityQueue<Process>(10, new ProcessArrivalTimeComparator());
		finishedQueue =  new PriorityQueue<Process>(10, new ProcessIDComparator());
		systemTime = 0;
		totalWaitTime = 0;
		totalTurnaroundTime = 0;
	}
	
	private void fillArrivalQueue(String inputFile) throws IOException
	{
		BufferedReader input = new BufferedReader(new FileReader(inputFile));
		while(input.ready())
			arrivalQueue.add(new Process(input.readLine()));
		input.close();		
	}
	
	private void runSimulation()
	{
		Process currentProcess;
		while((currentProcess = arrivalQueue.poll()) != null)
		{	
			if(systemTime < currentProcess.getArrivalTime())
				systemTime  = currentProcess.getArrivalTime();
			systemTime = currentProcess.runFor(systemTime, currentProcess.getRemainingBurstTime());
			finishedQueue.add(currentProcess);
			totalWaitTime += currentProcess.getCurrentWaitTime();
			totalTurnaroundTime += currentProcess.getTurnAroundTime();						
		}
	}

	private void writeResults(String outputFile) throws IOException
	{
		long aveWaitTime = Math.round((double)totalWaitTime/finishedQueue.size());
		long aveTurnaroundTime = Math.round((double)totalTurnaroundTime/finishedQueue.size());
		Process currentProcess;
		
		BufferedWriter outputter = new BufferedWriter (new FileWriter(outputFile)); 
		while((currentProcess = finishedQueue.poll()) != null)
		{
			outputter.write(currentProcess.output());
		}
		outputter.write(new String(aveWaitTime + " " + aveTurnaroundTime));

		outputter.close();
	}

  @Override
  public void schedule(String inputFile, String outputFile) 
  {
    // implement your scheduler here.
    // write the scheduler output to {@code outputFile}
	try
	{
		fillArrivalQueue(inputFile);
		runSimulation();
		writeResults(outputFile);
	}	 		
	catch (Exception e) 
	{
		System.out.println(e.getMessage());
	}

  }
}

/***
*	@author Mr.Shroom
*	Created by: Shaun McThomas
*	Last Modified:     06/10/15
*	This a simple class to represent a process in a scheduler algorithm
*	It will be used in simulations 
****/

import java.util.*;

public class Process
{
	private Long processId; //the process id
	private int arrivalTime; //the time the process arrived
	private int lastTime; //the last time the process had the CPU
	private int turnAroundTime;//the process turn around time
	private int burstTime; //the total burst time
	private int share; //the share used only for PS scheduler
	private int remainingBurstTime; //the remaining burst
	private int currentWaitTime; //the current amount of time the process has been waiting
	
	/**
	*constructor with needed parameters
	*
	**/
	public Process(String vals)
	{
		Scanner scanner =  new Scanner(vals);
		Long processId = new Long(scanner.nextLong());
		int arrivalTime = scanner.nextInt();
		int burstTime = scanner.nextInt();
		int share = (scanner.hasNextInt() ? scanner.nextInt() : 0);
		setAtributes(processId,arrivalTime, burstTime, share, burstTime, arrivalTime,0,0);
		scanner.close();
	}

	
	/**
	*constructor with needed parameters
	*
	**/
	public Process(Long processId,int arrivalTime, int burstTime, int share)
	{
		setAtributes(processId,arrivalTime, burstTime, share, burstTime, arrivalTime,0,0);
	}

	/**
	*constructor with needed parameters
	*
	**/
	public Process(Long processId,int arrivalTime, int burstTime)
	{
		setAtributes(processId,arrivalTime, burstTime, 0, burstTime, arrivalTime,0,0);
	}

	/**
	* copy constructor
	*
	**/
	public Process(Process toCopy)
	{
		setAtributes(toCopy.processId,toCopy.arrivalTime, toCopy.burstTime, 
								toCopy.share, toCopy.remainingBurstTime, toCopy.lastTime, 
								toCopy.currentWaitTime, toCopy.turnAroundTime );
	}
	
	/**
	*setter for process Attributes
	*
	**/
	private void setAtributes(Long processId, int arrivalTime, int burstTime, 
								int share, int remainingBurstTime, int lastTime, 
								int currentWaitTime, int turnAroundTime )
	{
		this.processId =new Long(processId);
		this.arrivalTime = arrivalTime;
		this.burstTime = burstTime;
		this.share = share;
		this.remainingBurstTime = remainingBurstTime;
		this.lastTime = lastTime;
		this.currentWaitTime = currentWaitTime;
		this.turnAroundTime = turnAroundTime;
	}
	/**
	*getter
	**/
	public Long getProcessId()
	{
		return processId;
	}

	/**
	*getter
	**/
	public int getArrivalTime()
	{
		return arrivalTime;
	}
	
	/**
	*getter
	**/
	public int getBurstTime()
	{
		return burstTime;
	}
	
	/**
	*getter
	**/
	public int getShare()
	{
		return share;
	}
	
	/**
	*getter
	**/
	public int getRemainingBurstTime()
	{
		return remainingBurstTime;
	}
	
	/**
	*getter
	**/
	public int getCurrentWaitTime()
	{
		return currentWaitTime;
	}
	
	/**
	*getter
	**/
	public int getTurnAroundTime()
	{
		return turnAroundTime;
	}

	/**
	*check if process is finished running
	**/
	public boolean isFinished ()
	{
		return (remainingBurstTime <= 0);
	}
	
	/**
	*	This function handles the running a process for a set amount of time.
	*	Where it finishes it returns what the new system time should be
	*
	*	@param systemTime	The system time before running the process
	*	@param runAmount	The amount of time allocated for the process to run.
	*
	*	@return				What the new system time should be.
	**/
	public int runFor (int systemTime, int runAmount)
	{
		if(!isFinished())                               //if the process is finished, we don't run it
		{
			if(remainingBurstTime < runAmount)      //make sure we don't run past the end 
				runAmount = remainingBurstTime;
				
			remainingBurstTime -= runAmount;		//logic involved in the running of a process
			currentWaitTime += (systemTime - lastTime);	//bookkeeping so we can easily know wait time 
			lastTime = systemTime + runAmount;		//needed to figure out wait and turn Around Time
			
			if(isFinished())
				turnAroundTime = lastTime - arrivalTime; //now that we're done we can calculate turn Around Time
			return lastTime;
		}
		return systemTime;
		
	}
	
	/**
	*	This function will output process as a string in the format request by the assignment
	*	<process-id> <finish-time> <wait-time> <turnaround-time>
	*
	*	@return			The requested string.
	**/
	public String output()
	{
		return(new String(processId + " " + lastTime + " " + currentWaitTime + " " + turnAroundTime + "\n"));
	}
	
	@Override 
	public String toString()
	{
		return(new String("[Process Id: " +             this.processId +
		                  "\nArrival Time: " +          this.arrivalTime+
		                  "\nInitail Burst time: " + this.burstTime  +
		                  "\nShare: " +                 this.share +
                                  "\nRemaining Burst time: " +  this.remainingBurstTime +
		                  "\nLast time it used CPU: "+  this.lastTime  +
                                  "\nCurrent wait time: " +	this.currentWaitTime  +
		                  "\nCurrent turnaround time(0 if unfinished): " + this.turnAroundTime +
		                  "]\n"));
	}
}
	
import java.util.Comparator;

public class ProcessArrivalTimeComparator implements Comparator<Process>
{
    @Override
    public int compare(Process x, Process y)
    {
        if (x.getArrivalTime() < y.getArrivalTime())
        {
            return -1;
        }
        if (x.getArrivalTime() > y.getArrivalTime())
        {
            return 1;
        }
	if(x.getArrivalTime() == y.getArrivalTime())
	{
		return x.getProcessId().compareTo(y.getProcessId());
	}
        return 0;
    }
}

import java.util.Comparator;

public class ProcessIDComparator implements Comparator<Process>
{
    @Override
    public int compare(Process x, Process y)
    {
	return x.getProcessId().compareTo(y.getProcessId());
    }
}

import java.util.Comparator;

public class ProcessRemainingTimeComparator implements Comparator<Process>
{
    @Override
    public int compare(Process x, Process y)
    {
        if (x.getRemainingBurstTime() < y.getRemainingBurstTime())
        {
            return -1;
        }
        if (x.getRemainingBurstTime() > y.getRemainingBurstTime())
        {
            return 1;
        }
	if(x.getRemainingBurstTime() == y.getRemainingBurstTime())
	{
		return x.getProcessId().compareTo(y.getProcessId());
	}
        return 0;
    }
}

/***
*	@author Mr.Shroom
*	Created by: Shaun McThomas
*	Last Modified:     06/10/15
*
 * Proportional share scheduler
 * Take total shares to be 100.
 * A process will not run unless it is completely given the requested share.
 */
 
import java.util.*;
import java.io.*;
 
public class PSScheduler implements Scheduler 
{
        private static final int TOTAL_SHARES = 100;
        private static final boolean DEBUG_MODE = false;
        
        private PriorityQueue<Process> arrivalQueue,finishedQueue;
        private PriorityQueue<Process> readyQueue;
        private LinkedList<Process> runningList;
        private LinkedList<Integer> startSystemTime;
        
        private int systemTime, totalWaitTime, totalTurnaroundTime, curentSharesLeft;
        
        public PSScheduler()
	{
		arrivalQueue = new PriorityQueue<Process>(10, new ProcessArrivalTimeComparator());
		finishedQueue =  new PriorityQueue<Process>(10, new ProcessIDComparator());
		readyQueue =  new PriorityQueue<Process>(10, new ProcessIDComparator());
		runningList = new LinkedList<Process>();
		startSystemTime = new LinkedList<Integer>();
		systemTime = 0;
		totalWaitTime = 0;
		totalTurnaroundTime = 0;
		curentSharesLeft = TOTAL_SHARES;
	}
	
	private void fillArrivalQueue(String inputFile) throws IOException
	{
	       if (DEBUG_MODE)
                        System.out.println("file: " + inputFile + "\n***************************************");
                        
		BufferedReader input = new BufferedReader(new FileReader(inputFile));
		
		while(input.ready())
			arrivalQueue.add(new Process(input.readLine()));
		
		input.close();		
	}
	
	private void fillReadyQueue(int tempSystemTime)
	{
	        while(!arrivalQueue.isEmpty() && (readyQueue.isEmpty() || (arrivalQueue.peek().getArrivalTime() <= tempSystemTime )))
	                readyQueue.add(arrivalQueue.poll()); 
	}
	
	private void fillRunningList(int tempSystemTime)
	{
	        while(!readyQueue.isEmpty() && readyQueue.peek().getShare() <= curentSharesLeft) 
	        {
	                curentSharesLeft -= readyQueue.peek().getShare();
	                runningList.add(readyQueue.poll());
	                startSystemTime.add(tempSystemTime);
	        }
	}
	
	private void runSimulation()
	{
		Process currentProcess;
		int runtime, temp;
	        int currentPos = 0 ;		
                
                fillReadyQueue(systemTime);
		fillRunningList(systemTime);
		
		while(!arrivalQueue.isEmpty() || !runningList.isEmpty()|| !readyQueue.isEmpty())
		{ 
                        for(int itr = 0; itr < runningList.size();itr++)
                        {                                                             
                                currentProcess = runningList.get(itr);
                                
                                if (DEBUG_MODE)
                                {                                        
                                        System.out.println(currentProcess.toString());
                                        System.out.println("System Time:  " + startSystemTime.get(itr));
                                        pressAnyKeyToContinue();
                                }
                                
                                runtime =  currentProcess.getRemainingBurstTime();                                                
                                temp = currentProcess.runFor(startSystemTime.get(itr), runtime);
                                
                                if (DEBUG_MODE)
                                        System.out.println("temp : " + temp + "\n");
                                
                                if(temp > systemTime)
                                        systemTime = temp; 
                                        
			        if(currentProcess.isFinished())
			        { 		          
				        finishedQueue.add(currentProcess);
				        totalWaitTime += currentProcess.getCurrentWaitTime();
				        totalTurnaroundTime += currentProcess.getTurnAroundTime();
				        curentSharesLeft += currentProcess.getShare();
				        runningList.remove(itr);
				        startSystemTime.remove(itr);
				        itr--;				      
			        }
			        
			        fillReadyQueue(temp);  
			        fillRunningList(temp);	  
			}		
				
		}
	}


        @Override
        public void schedule(String inputFile, String outputFile) 
        {

	        try
	        {
		        fillArrivalQueue(inputFile);		        
	        	runSimulation();
	        	
	        	writeResults(outputFile);
	        }	 		
	        catch (Exception e) 
	        {	                
		        System.out.println(e.getMessage());
		        System.out.println(e.toString());
		        e.printStackTrace();
	        }
        }
  
  	private void writeResults(String outputFile) throws IOException
	{
		long aveWaitTime = Math.round((double)totalWaitTime/finishedQueue.size());
		long aveTurnaroundTime = Math.round((double)totalTurnaroundTime/finishedQueue.size());
		Process currentProcess;
		
		BufferedWriter outputter = new BufferedWriter (new FileWriter(outputFile)); 
		while((currentProcess = finishedQueue.poll()) != null)
		{
			outputter.write(currentProcess.output());
		}
		outputter.write(new String(aveWaitTime + " " + aveTurnaroundTime));
		outputter.close();
	}
	
	        
	private void pressAnyKeyToContinue()
        { 
                System.out.println("Press any key to continue...");
                try
                {
                        System.in.read();
                }         
                catch(Exception e)
                {
                }
        }
	
}

/***
*	@author Mr.Shroom
*	Created by: Shaun McThomas
*	Last Modified:     06/10/15
*
 * Shortest remaining time first scheduler
 */
 
import java.util.*;
import java.io.*;
 
public class SRTFScheduler implements Scheduler 
{
        private static final boolean DEBUG_MODE = false;
        private PriorityQueue<Process> arrivalQueue, readyQueue,finishedQueue;
        private int systemTime, totalWaitTime, totalTurnaroundTime;

        public SRTFScheduler()
        {
                arrivalQueue = new PriorityQueue<Process>(10, new ProcessArrivalTimeComparator());
	        readyQueue = new PriorityQueue<Process>(10, new ProcessRemainingTimeComparator());
	        finishedQueue =  new PriorityQueue<Process>(10, new ProcessIDComparator());
		systemTime = 0;
		totalWaitTime = 0;
		totalTurnaroundTime = 0;
	}
	
	private void fillArrivalQueue(String inputFile) throws IOException
	{
                if (DEBUG_MODE)
                        System.out.println("file: " + inputFile);
                        
		BufferedReader input = new BufferedReader(new FileReader(inputFile));
		while(input.ready())
        		arrivalQueue.add(new Process(input.readLine()));
		input.close();		
	}
	
	private Process nextProcess()
	{        
	        if  (readyQueue.isEmpty() || 
	                (!arrivalQueue.isEmpty() && arrivalQueue.peek().getArrivalTime() <= systemTime ))
	        {
	                int arrived = arrivalQueue.peek().getArrivalTime();	                
	                while(!arrivalQueue.isEmpty() && arrived == arrivalQueue.peek().getArrivalTime())	               
	                        readyQueue.add(arrivalQueue.poll());	                
	        }     
	        
	        return readyQueue.poll();	       
	}
	
	private int figureOutRunTime(Process currentProcess)
	{
	        int minTime = currentProcess.getRemainingBurstTime();	        
	                
	        if (!arrivalQueue.isEmpty())
	                minTime = Math.min(minTime, (arrivalQueue.peek().getArrivalTime() - systemTime));
	                	  	
	        return minTime;
	}
	
	private void runSimulation()
	{
		Process currentProcess;
		int runtime;		

		while(!arrivalQueue.isEmpty() || !readyQueue.isEmpty())
		{	        
		        currentProcess = nextProcess();
		        
		        if (DEBUG_MODE)
		        {
		                System.out.println("\n*********************************************************************");
        		        System.out.println(currentProcess.toString());
	                }
	                	        
		        if(systemTime < currentProcess.getArrivalTime())
				systemTime  = currentProcess.getArrivalTime();
				
		        runtime = figureOutRunTime(currentProcess);
		        
		        if(DEBUG_MODE)
		        {
        		        System.out.println("will run: " + runtime);
        		        pressAnyKeyToContinue();
			}
				
			systemTime = currentProcess.runFor(systemTime, runtime);
			
			if(currentProcess.isFinished())
			{
				finishedQueue.add(currentProcess);
				totalWaitTime += currentProcess.getCurrentWaitTime();
				totalTurnaroundTime += currentProcess.getTurnAroundTime();
							
			}
			else
			        readyQueue.add(currentProcess);			
				
		}
	}
	
	private void writeResults(String outputFile) throws IOException
	{
		long aveWaitTime = Math.round((double)totalWaitTime/finishedQueue.size());
		long aveTurnaroundTime = Math.round((double)totalTurnaroundTime/finishedQueue.size());
		Process currentProcess;
		
		BufferedWriter outputter = new BufferedWriter (new FileWriter(outputFile)); 
		while((currentProcess = finishedQueue.poll()) != null)
		{
			outputter.write(currentProcess.output());
		}
		outputter.write(new String(aveWaitTime + " " + aveTurnaroundTime));

		outputter.close();
	}

        @Override
  	public void schedule(String inputFile, String outputFile) 
	{

		try
	        {
		        fillArrivalQueue(inputFile);
		        runSimulation();
		        writeResults(outputFile);
	        }	 		
	        catch (Exception e) 
	        {
		        System.out.println(e.getMessage());
	        }
        }
        
        private void pressAnyKeyToContinue()
        { 
                System.out.println("Press any key to continue...");
                try
                {
                        System.in.read();
                }         
                catch(Exception e)
                {
                }
        }
}

/**
 * Interface to be implemented by each scheduler algorithm.
 */
public interface Scheduler {

  /**
   * Schedule the processes given in {@code inputFile} and write the results to
   * given {@code outputFile}.
   * @param inputFile
   * @param outputFile
   */
  public void schedule(String inputFile, String outputFile);
}
