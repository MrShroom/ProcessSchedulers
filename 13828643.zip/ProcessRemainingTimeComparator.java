import java.util.Comparator;

public class ProcessRemainingTimeComparator implements Comparator<Process>
{
    @Override
    public int compare(Process x, Process y)
    {
        if (x.getRemainingBurstTime() < y.getRemainingBurstTime())
        {
            return -1;
        }
        if (x.getRemainingBurstTime() > y.getRemainingBurstTime())
        {
            return 1;
        }
	if(x.getRemainingBurstTime() == y.getRemainingBurstTime())
	{
		return x.getProcessId().compareTo(y.getProcessId());
	}
        return 0;
    }
}
