import java.util.Comparator;

public class ProcessIDComparator implements Comparator<Process>
{
    @Override
    public int compare(Process x, Process y)
    {
	return x.getProcessId().compareTo(y.getProcessId());
    }
}
